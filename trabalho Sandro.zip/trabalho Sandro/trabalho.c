#include <stdio.h>
#include <stdlib.h>
#include <string.h>
    /*
 4) Crie uma struct para armazenar os dados de cada átomo: 
                        a) Número que o identifica
                        b) O nome do átomo (N, CA, C, O, CB, SG, etc)
                        c) O nome do aminoácido (GLY, CYS, SER, etc)
                        d) As coordenadas atômicas X, Y, Z - colunas 7, 8 e 9
                        */
 typedef struct propriedades
 {
   int num;
   char nome[4];
   char aminoacido[6];
   float x ;
   float y;
   float z;
   struct propriedades *prox;
 }ATOM;

 int abrirArq(FILE ** pont , char * nome , char  *abertura);
int listaencadea(ATOM **lista , FILE **pont);
void Listar(ATOM **lista);
int Menu(ATOM **lista,char *arquivo,int qtd);
 /*
 1) Leia do prompt de comando os nomes dos arquivos de entrada e saída. 
Por exemplo: ./TP-Sandro entrada.pdb saida.txt
 */
int main(int argc , char *argv[]){
     FILE *pont_arq;
     int verifica;
     int teste;
    ATOM *lista;
    int cont;
    lista = NULL;
    if(argc!=3){
         printf("Erro! , poucos parametros passados na linha de comando\n");
         exit(0);
    }
    /* 2) Abra o arquivo de entrada e leia a quantidade (N) de linhas do arquivo 
    que iniciem pela palavra ATOM. O arquivo de entrada é um arquivo que 
    contém a estrutura tridimensional de uma proteína, como pode ser visto
     a seguir. As linhas iniciadas por ATOM contém informações sobre cada
      átomo que compõe e proteína.
    */
    verifica = abrirArq(&pont_arq,argv[1],"r");
    if(verifica==1){
            printf("Erro na alocação ! \n ");
            exit(1);
    }
    cont = listaencadea(&lista,&pont_arq);
    fclose(pont_arq);
        //3) Imprima na tela a quantidade total de átomos presentes no arquivo.
       printf("Quantidade total de átomos presentes no arquivo: %d\n",cont);
       
       while(teste!=1){
           teste = Menu(&lista,argv[2],cont);
       }
    return 0;
}

int abrirArq(FILE **pont , char * nome , char * abertura){
    *pont = fopen(nome,abertura);
    if(*pont!=NULL){
        return 0;
    }
    return 1;
}
int listaencadea(ATOM **lista , FILE **pont){
    char linha[2000];
    int cont=0;
    char int_1;
    int int_2;
    float int_3 , int_4;
    char int_5;
    ATOM *dados;
    ATOM *aux;
     
        while(fgets(linha,sizeof(linha),*pont)!=NULL){
                if( linha[0]=='A' &&  linha[1]=='T' && linha[2]=='O' && linha[3]=='M'){
                    cont++;
                    /*
                    5) Crie uma lista encadeada para os átomos que forem lidos do arquivo, 
                    a partir da struct criada anteriormente, fazendo a alocação dinâmica 
                    dos elementos da lista à medida que forem lidos.
                    */
                    dados = (ATOM *) malloc(sizeof(ATOM));
                    if(dados!=NULL){
                             sscanf(linha,"%*s %d %s %s %c %d %f %f %f %f %f %c",&dados->num,dados->nome,dados->aminoacido,&int_1,&int_2,&dados->x,&dados->y,&dados->z,&int_3,&int_4,&int_5);
                            dados->prox = NULL;
                            if(*lista==NULL){
                            *lista = dados;  
                      }
                      else{
                          aux = *lista;
                          while(aux->prox!=NULL)
                          aux = aux->prox;
                            aux->prox = dados;
                      }
                  }
             }   
     }
        return cont;
}
void Listar(ATOM **lista){
    ATOM *aux;
    aux = *lista;
    while(aux!=NULL){
        printf("%d %s %s %f %f %f\n",aux->num,aux->nome,aux->aminoacido,aux->x,aux->y,aux->z);
        aux = aux->prox;
    }
}
void Saida(ATOM **lista,char *arquivo, int qtd){
    FILE *saida;
    ATOM *aux;
    aux = *lista;
    int i;
    saida = fopen(arquivo,"w");
    
     while(aux!=NULL){
        fprintf(saida,"%d %s %s %f %f %f\n",aux->num,aux->nome,aux->aminoacido,aux->x,aux->y,aux->z);
        aux = aux->prox;
    }
    fclose(saida);

}
int Menu(ATOM **lista,char *arquivo,int qtd){
    int verifica;
    printf("O que você deseja fazer ? \n");
    printf("1) Listar todos os átomos e suas características constantes na lista criada\n");
    printf("2) Gerar arquivo de saída \n");
    scanf("%d",&verifica);
    if(verifica==1){
        Listar(*&lista);
        return 0;
    }
    else if(verifica==2){
        Saida(*&lista,arquivo,qtd);
    }
    else
    return 1;
    
}

