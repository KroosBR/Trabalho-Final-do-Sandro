#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int abrirArq(FILE ** pont , char * nome , char  *abertura);
int qtdAtomos(FILE ** pont);
  
 typedef struct propriedades
 {
   int num;
   char nome[4];
   char aminoacido[6];
   double x , y, z;
 }ATOM;

 /*
 1) Leia do prompt de comando os nomes dos arquivos de entrada e saída. 
Por exemplo: ./TP-Sandro entrada.pdb saida.txt
 */
 
int main(int argc , char *argv[]){
    FILE *pont_arq;
    int verifica;
    char linha[2000];
    int cont=0;
    int i=0;
    int j;
 
    if(argc!=3){
        printf("Erro! , poucos parametros passados na linha de comando\n");
        exit(0);
    }
    verifica = abrirArq(&pont_arq,argv[1],"r");
    if(verifica==1){
        printf("Erro na alocação ! \n ");
        exit(1);
    }
    /*
    2) Abra o arquivo de entrada e leia a quantidade (N) de linhas do arquivo 
    que iniciem pela palavra ATOM. O arquivo de entrada é um arquivo que 
    contém a estrutura tridimensional de uma proteína, como pode ser visto
     a seguir. As linhas iniciadas por ATOM contém informações sobre cada
      átomo que compõe e proteína.
    */
        while(fgets(linha,sizeof(linha),pont_arq)!=NULL){
                if( linha[0]=='A' &&  linha[1]=='T' && linha[2]=='O' && linha[3]=='M'){
                    cont++ ;
                }
        }
        /*
        3) Imprima na tela a quantidade total de átomos presentes no arquivo.
        */
       printf("Quantidade total de átomos presentes no arquivo: %d",cont);
    
}
int abrirArq(FILE **pont , char * nome , char * abertura){
    *pont = fopen(nome,abertura);
    if(*pont!=NULL){
        return 0;
    }
    return 1;
}

